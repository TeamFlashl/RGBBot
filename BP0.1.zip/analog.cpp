//#include "analog.h"

void setup() {
    // ...existing setup code...
}

void loop() {
    setRGB(0, 0, 255);
    delay(1000);
    setRGB(0, 255, 0);
    delay(1000);
}