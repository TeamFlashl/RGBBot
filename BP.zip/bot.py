# ----- bot.py -----
import config
import telebot
import serial
import time 

from config import TOKEN

# Настройки
TOKEN = config.TOKEN
SERIAL_PORT = "COM3"   # или COM3 на Windows
BAUDRATE = 9600

# Инициализация
bot = telebot.TeleBot(TOKEN)
try:
    ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
    time.sleep(2)  # дать Arduino время перезагрузиться
except Exception as e:
    print("Не получается открыть последовательный порт:", e)
    exit(1)

# Простая клавиатура
from telebot.types import ReplyKeyboardMarkup, KeyboardButton

markup = ReplyKeyboardMarkup(resize_keyboard=True)
markup.row(KeyboardButton("🔴 Красный"), KeyboardButton("🟢 Зелёный"), KeyboardButton("🔵 Синий"))
markup.row(KeyboardButton("⚪️ Белый"), KeyboardButton("Зелёный мигалка"), KeyboardButton("🔦 Выкл"))
markup.row(KeyboardButton("Настроить RGB"))


@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.send_message(message.chat.id,
                     "Привет! Я управлю RGB-лентой.\n"
                     "Выберите готовый цвет или задайте свой через /rgb R G B",
                     reply_markup=markup)

@bot.message_handler(commands=['rgb'])
def custom_rgb(message):
    parts = message.text.split()
    if len(parts) != 4:
        bot.reply_to(message, "Неверный формат. Используйте: /rgb R G B (0–255)")
        return
    try:
        r, g, b = map(int, parts[1:])
        for v in (r, g, b):
            if not 0 <= v <= 255:
                raise ValueError
    except:
        bot.reply_to(message, "Значения должны быть числами 0–255")
        return
    send_to_arduino(r, g, b, message)

@bot.message_handler(func=lambda m: True)
def choose_color(message):
    text = message.text.lower()
    if "красн" in text:
        send_to_arduino(255,0,0, message)
    elif "зелёный мигалка" in text:
        send_mode1_to_arduino(message)
    elif "зелён" in text:
        send_to_arduino(0,255,0, message)
    elif "син" in text:
        send_to_arduino(0,0,255, message)
    elif "бел" in text:
        send_to_arduino(255,255,255, message)
    elif "выкл" in text:
        send_to_arduino(0,0,0, message)
    else:
        bot.reply_to(message, "Не понял команду, выберите цвет на клавиатуре или /rgb R G B")

def send_mode1_to_arduino(message):
    try:
        ser.write(b"mode1\n")
        time.sleep(0.1)
        resp = ser.readline().decode().strip()
        if resp.startswith("OK"):
            bot.reply_to(message, "Включён режим: Зелёный мигалка")
        else:
            bot.reply_to(message, "Нет ответа от Arduino")
    except Exception as e:
        bot.reply_to(message, f"Ошибка отправки на Arduino: {e}")

def send_to_arduino(r, g, b, message):
    cmd = f"{r},{g},{b}\n"
    try:
        ser.write(cmd.encode())
        time.sleep(0.1)
        resp = ser.readline().decode().strip()
        if resp.startswith("OK"):
            bot.reply_to(message, f"Установлен цвет R={r},G={g},B={b}")
        else:
            bot.reply_to(message, "Нет ответа от Arduino")
    except Exception as e:
        bot.reply_to(message, f"Ошибка отправки на Arduino: {e}")


def sum(a, b):
    return a + b    

if __name__ == '__main__':
    print("Бот запущен...")
    bot.infinity_polling()